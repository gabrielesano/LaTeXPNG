MathJax = {
    tex: { packages: { '[+]': ['braket'] } }
};
